# LocalLibrary
- Django	3.2.25
- Python 3.7
- db.sqlite3
# Библиотеки
- Django	3.2.25	5.1.3
- asgiref	3.7.2	3.8.1
- bootstrap4	0.1.0	0.1.0
- pip	23.2.1	24.3.1
- pytz	2024.2	2024.2
- setuptools	68.0.0	75.3.0
- sqlparse	0.4.4	0.5.1
- typing-extensions	4.7.1	4.12.2
- wheel	0.41.2	0.44.0
# Установка
- Открыть проект в Pycharm
- В качестве интерпретатора выбрать Python 3.7
- Прописать в терминале команду: pip install django
